# ~ https://newsapi.org/v2/everything?q=tesla&from=2021-09-09&sortBy=publishedAt&apiKey=007b494a517f4d9aba840e9e96e2cb66
import datetime
from django.shortcuts import render,redirect
import json
import os
import urllib.request as URL
def get_data(req):
	return render(req,'a.json');
def home(req):	
	BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/htmls/cur.txt"
	current_date = str(datetime.date.today()).replace('\n','')
	last_time = ""
	with open(BASE_DIR,'r') as f :
		last_time = f.read()
	if last_time != current_date:
		print('data updated')
		with open(BASE_DIR,'W+') as f:
			f.write(current_date);
			return reload(req)
	return render(req,'a.json');
def reload():
	BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))+"/htmls/a.json"
	# ~ print(BASE_DIR)
	data = json.loads(URL.urlopen("https://newsapi.org/v2/everything?q=tesla&from=2021-09-09&sortBy=publishedAt&apiKey=007b494a517f4d9aba840e9e96e2cb66").read());
	# ~ FILE_DIR = os.path.dirname(os.path.abspath(__file__)) + '/a.json'
	with open(BASE_DIR,'w+') as f:
		data = str(data).replace("'",'"')
		f.write(data);
		print(f.read())
	return redirect('http://127.0.0.1:8000/');
